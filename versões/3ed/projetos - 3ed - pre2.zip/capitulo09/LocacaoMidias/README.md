# Sobre

Modelo para projeto de locação de mídias da disciplina de IDSW (Introdução ao Desenvolvimento de Software para Web) do curso de Bacharelado em Ciência da Computação do IFSP, câmpus São João da Boa Vista.

Prof. Dr. David Buzatto