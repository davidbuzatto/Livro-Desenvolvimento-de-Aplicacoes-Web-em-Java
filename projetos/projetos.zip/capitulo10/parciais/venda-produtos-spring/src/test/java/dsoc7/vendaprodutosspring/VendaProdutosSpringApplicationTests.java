package dsoc7.vendaprodutosspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendaProdutosSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
